nome = input("Entre com o primeiro nome: ")
nome_do_meio = input("Entre com o nome do meio: ")
sobrenome = input("Entre com seu sobrenome: ")
nome_completo = nome + ' ' + nome_do_meio + ' ' + sobrenome

print(f"Nome completo: {nome_completo} !")


print("Alterando data")
print("================================")
data = input("Digite a data: ")
dia = data[0:2]
mes = data[3:5]
ano = data[6:10]
nova_data = ano+mes+dia
print(nova_data)

frase = input("Digite a frase: ").upper()
palavra = input("Digite a palavra: ").upper()

qtd = frase.count(palavra)

print(f"A quantidade de repetição é igual a = {qtd}")
print("Concatenando Nome")
print("==================================")
nome = input("Digite seu primeiro nome: ")
sobrenome = input("Digite seu Sobrenome: ")
nome_completo = nome + ' ' + sobrenome
print(f"Nome Completo {nome_completo}.")
#Criptografia
nome_cripto = ''
for i in range(0, len(nome_completo)):
    nome_cripto += chr(ord(nome_completo[i])+1)

print(f"Nome Cripto: {nome_cripto}.")



idade = input("Entre com sua idade: ")
idade.is
if idade.isdigit():
    idade = int(idade)
    print(idade)
else:
    print("Você digitou uma idade inválida!!")


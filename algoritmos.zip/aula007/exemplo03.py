for elemento in range(10):
    if elemento == 17:
        break
    print(elemento)
else:
    print("Laço chegou ao fim")

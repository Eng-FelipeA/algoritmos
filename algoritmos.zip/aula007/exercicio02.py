print("Somando pares")
print("=======================")
x = 0
par = 2
for i in range(50):
    x = x + par
    par = par + 2
print(f"A soma dos 50 primeiros numeros pares é {x}")
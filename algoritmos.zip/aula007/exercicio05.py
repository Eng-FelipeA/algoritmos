print("Área de um triêngulo")
print("=================================")
base = float(input("Digite a base do triângulo: "))
while base <= 0:
    base = float(input("Digite a base de do triângulo > 0: "))

while True:
    altura = float(input("Digite a altura do triângulo: "))
    if altura >= 0:
        break
area = (base*altura)/2
input(f"A área é:{area:.2f}m²")


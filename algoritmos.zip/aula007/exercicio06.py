print("Fatorial")
print("==========================")
while True:
    x = int(input("Digite um número: "))
    if x >= 0:
        break
    print("Valor inválido. Precisa ser > 0: !")

if (x == 0) or (x == 1):
    fatorial = 1
else:
    fatorial = 1
    for i in range(1, x+1):
        fatorial = fatorial * i
print(f"O valor de de {x}! é {fatorial}")

vetor = []
for i in range(5):
    x = int(input(f"Digite o {i+1}o. valor: "))
    vetor.append(x) #dessa forma
print(vetor[::-1])
vetor.reverse() #ou dessa forma
print(vetor)
c = int(input("Digite a temperatura: "))
f = ( 9 * c + 160 ) / 5
print("Temperatura em F: ", f)

nome = input("Digite seu nome: ")
print("Bom dia,", nome, "!", sep = '')
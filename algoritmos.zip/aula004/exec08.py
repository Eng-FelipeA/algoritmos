base = float(input("Digite a Base: "))
altura = float(input("Digite a Altura: "))
area = (base * altura) / 2
print(f"A área do triangulo é {area}")
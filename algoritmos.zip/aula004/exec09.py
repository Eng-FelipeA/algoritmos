from math import pi, pow
raio = float(input("Digite o valor do raio: "))
area = pi * pow(raio, 2)
print(f"O valor da área do circulo é {area:.3}")
print(f"Valor de pi: {pi}")
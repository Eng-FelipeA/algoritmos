telefones = {
    "maria": 996914545,
    "jose": 996914242,
    "ana": 996913535
}

for nome, celular in telefones.items():
    print(f"O {nome} tem o seguinte celular {celular}!")

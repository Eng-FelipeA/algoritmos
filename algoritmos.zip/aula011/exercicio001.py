t = ()
for i in range(5):
    x = int(input(f"Digite o {i+1}o. numero: "))
    t = t + (x,)

print(t[::-1])

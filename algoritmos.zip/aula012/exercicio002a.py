def primo(n):
    i = 1
    contador = 0
    while i <= n:
        if (n % i) == 0:
            contador += 1
        i += 1
    if contador == 2:
        return True
    else:
        return False

print("Os primeiros 50 números primos são: ")
i, n = 2, 0
while n <= 50:
    if primo(i):
        print(i, end=" - ")
        n += 1
    i += 1

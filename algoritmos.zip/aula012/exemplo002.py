def soma(n1,n2):
    resultado = n1 + n2
    return n1+n2
#... após definir a função, realizar o cálculo.
a = int(input("Digite valor 1: "))
b = int(input("Digite valor 2: "))
print(f"O valor da soma é igual a {soma(a,b)}")
#...resultado é uma variável local e não será executada, já "a" e "b"
# são variáveis globais e irão aparecer em todo o código
print(resultado)
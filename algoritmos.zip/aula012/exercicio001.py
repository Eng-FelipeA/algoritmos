def par(a):
    resultado = a % 2 == 0
    return resultado #...ou eliminar resultado e colocar return ( a % 2 = =0)
a = int(input("Digite um número inteiro: "))
if par(a):
    print("O número é par!")
else:
    print("O número é ìmpar!")
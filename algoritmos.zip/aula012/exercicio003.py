def ebissexto(ano):
    if ano % 4 == 0:
        if ano % 100 == 0:
            if ano % 400 == 0:
                return True
            else:
                return False
        else:
            return True
    else:
        return False

ano = int(input("Digite o ano: "))
if ebissexto(ano):
    print(ano, "É ano bissexto!")
else:
    print(ano, "Não é bissexto!")
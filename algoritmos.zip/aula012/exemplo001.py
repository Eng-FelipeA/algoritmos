def desenha(n=50, x=0):
    for i in range(x,n):
        print("-", end='')
    print()
#...se não colocar nenhum parâmetro, a função asumirá o padrão indiicado.
desenha()
print("** usando funções **")
desenha(30)

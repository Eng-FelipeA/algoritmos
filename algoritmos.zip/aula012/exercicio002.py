def primo(a):
    i = 1
    contador = 0
    while i <= a:
        if (a % i) == 0:
            contador =+ 1
        i += 1
    if contador == 2:
        return True
    else:
        return False
    return
a = int(input("Digite um número inteiro: "))
if primo(a):
    print("O número é primo!")
else:
    print("O número não é primo!")
import exemplo001

for i in range(0,11):
    print(exemplo001.fib(i), end=' ')

'''ou
from exemplo001 import fib
for i in range(0,11):
    print(fib(i), end=' ') não há necessidade de buscar o arquivo exemplo001
'''
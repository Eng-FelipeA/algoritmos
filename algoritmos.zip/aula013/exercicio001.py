import random
def joga_dado():
    while True:
        input("Pressione enter para jogar dados")
        dado1 = random.randint(1,6)
        print("Usuário:", dado1)
        input("Pressione enter para o computador jogar o dado")
        dado2 = random.randint(1, 6)
        print("Computador:", dado2)
        if dado1 > dado2:
            print("Você ganhou!!")
        elif dado1 == dado2:
            print("Empatamos!")
        else:
            print("Que pena...Você perdeu.")
    return
print(joga_dado())

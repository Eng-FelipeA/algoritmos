telefones = {
    "maria": 99923432,
    "jose": 98876676,
    "ana": 88998334,
    "joão": 99898766
}

for nome, celular in telefones.items():
    print(f"O {nome} tem o seguinte celular {celular}!")




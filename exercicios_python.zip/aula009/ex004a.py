matriz = []
for i in range(3):
    linha = []
    for j in range(3):
        elemento = float(input(f"Digite o elemento da posição [{i}][{j}]: "))
        linha.append(elemento)
    matriz.append(linha)

matriz_transposta = []
for j in range(3):
    linha_transposta = []
    for i in range(3):
        linha_transposta.append(matriz[i][j])
    matriz_transposta.append(linha_transposta)

print("Matriz Transposta:")
for linha in matriz_transposta:
    print(linha)

def obter_maior_elemento(matriz):
    maior = matriz[0][0]
    for linha in matriz:
        for elemento in linha:
            if elemento > maior:
                maior = elemento
    return maior

def multiplicar_matriz_por_maior(matriz, maior):
    matriz_resultante = []
    for linha in matriz:
        nova_linha = [elemento * maior for elemento in linha]
        matriz_resultante.append(nova_linha)
    return matriz_resultante

matriz = []
for i in range(2):
    linha = []
    for j in range(2):
        elemento = int(input(f"Digite o elemento da posição [{i}][{j}]: "))
        linha.append(elemento)
    matriz.append(linha)

maior_elemento = obter_maior_elemento(matriz)

matriz_resultante = multiplicar_matriz_por_maior(matriz, maior_elemento)

print("Matriz Resultante:")
for linha in matriz_resultante:
    print(linha)

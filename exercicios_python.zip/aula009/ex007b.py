def verificar_simetria(matriz):
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            if matriz[i][j] != matriz[j][i]:
                return False
    return True

matriz = [[0] * 8 for _ in range(8)]

for i in range(8):
    for j in range(8):
        matriz[i][j] = int(input(f"Digite o valor para a posição [{i+1}][{j+1}]: "))

simetrica = verificar_simetria(matriz)

if simetrica:
    print("A matriz é simétrica.")
else:
    print("A matriz não é simétrica.")

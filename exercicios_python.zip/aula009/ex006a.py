def somar_linhas(matriz):
    soma_linhas = []

    for linha in matriz:
        soma = sum(linha)
        soma_linhas.append(soma)

    return soma_linhas

def multiplicar_matriz(matriz, vetor_somas):
    matriz_resultante = []

    for i in range(len(matriz)):
        linha_resultante = []
        for j in range(len(matriz[i])):
            elemento_resultante = matriz[i][j] * vetor_somas[i]
            linha_resultante.append(elemento_resultante)
        matriz_resultante.append(linha_resultante)

    return matriz_resultante

matriz = [[0] * 20 for _ in range(10)]

for i in range(10):
    for j in range(20):
        matriz[i][j] = int(input(f"Digite o valor para a posição [{i+1}][{j+1}]: "))

soma_linhas = somar_linhas(matriz)

matriz_resultante = multiplicar_matriz(matriz, soma_linhas)

for linha in matriz_resultante:
    print(linha)

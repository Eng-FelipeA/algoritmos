def encontrar_maior_elemento(matriz):
    maior_elemento = matriz[0][0]
    linha_maior_elemento = 0
    coluna_maior_elemento = 0

    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            if matriz[i][j] > maior_elemento:
                maior_elemento = matriz[i][j]
                linha_maior_elemento = i
                coluna_maior_elemento = j

    return linha_maior_elemento, coluna_maior_elemento

matriz = [[0] * 10 for _ in range(10)]

for i in range(10):
    for j in range(10):
        matriz[i][j] = int(input(f"Digite o valor para a posição [{i+1}][{j+1}]: "))

linha_maior, coluna_maior = encontrar_maior_elemento(matriz)
print(f"A posição do maior elemento é: linha {linha_maior + 1}, coluna {coluna_maior + 1}")

palavras = []

for i in range(5):
    palavra = input(f"Digite a palavra {i + 1}: ")
    palavras.append(palavra)

palavras_invertidas = [palavra[::-1] for palavra in palavras]

print("Palavras invertidas:")
for palavra in palavras_invertidas:
    print(palavra)

matriz = []
for i in range(4):
    linha = []
    for j in range(4):
        elemento = float(input(f"Digite o elemento da posição [{i}][{j}]: "))
        linha.append(elemento)
    matriz.append(linha)

soma_diagonal = 0
for i in range(4):
    soma_diagonal += matriz[i][i]

print("Soma dos elementos da diagonal principal:", soma_diagonal)

vetor_A = []

for i in range(10):
    numero = int(input(f"Digite o número {i + 1}: "))
    vetor_A.append(numero)

vetor_B = sorted(vetor_A)

print("Vetor A:", vetor_A)
print("Vetor B:", vetor_B)

import random

frequencia = {n: 0 for n in range(2, 13)}

for _ in range(30000):
    dado1 = random.randint(1, 6)
    dado2 = random.randint(1, 6)
    soma = dado1 + dado2
    frequencia[soma] += 1

total_jogadas = 30000
frequencia_relativa = {soma: contagem / total_jogadas for soma, contagem in frequencia.items()}

print("Frequência Relativa:")
for soma, relativa in frequencia_relativa.items():
    print(f"Soma {soma}: {relativa:.3f}")

frequencia_7 = frequencia_relativa[7]
probabilidade_7 = 1 / 6
print(f"\nFrequência do valor 7: {frequencia_7:.3f}")
print(f"Probabilidade de valor 7: {probabilidade_7:.3f}")

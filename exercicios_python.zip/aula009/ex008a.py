def calcular_media_linhas_pares(matriz):
    soma = 0
    count = 0

    for i in range(len(matriz)):
        if i % 2 == 0:
            for j in range(len(matriz[i])):
                soma += matriz[i][j]
                count += 1

    if count == 0:
        return 0
    else:
        return soma / count

matriz = [[0.0] * 5 for _ in range(5)]

for i in range(5):
    for j in range(5):
        matriz[i][j] = float(input(f"Digite o valor para a posição [{i+1}][{j+1}]: "))

media_linhas_pares = calcular_media_linhas_pares(matriz)

print(f"A média dos elementos das linhas pares é: {media_linhas_pares}")

from random import randint

def rola_dado():
    return randint(1,6)
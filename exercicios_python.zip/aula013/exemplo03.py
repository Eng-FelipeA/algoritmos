from random import randint

print(randint(1, 100))
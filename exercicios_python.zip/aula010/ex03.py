x = range(20)
x = list(x)
for z in x[3:8]:
    print(z)
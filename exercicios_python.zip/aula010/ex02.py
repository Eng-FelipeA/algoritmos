var= 0
while var < 6:
    var +=1
    if var % 2 == 0:
        continue
    print("#")
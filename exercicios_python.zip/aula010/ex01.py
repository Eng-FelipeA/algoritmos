vals = [0, 1, 2]
print(vals)
vals.insert(0,1)
print(vals)
del vals[1]
print(vals)

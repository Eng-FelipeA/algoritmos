frutas = ['banana', 'laranja', 'manga', 'uva']
for k in range(-1, -4, -2):
    print(frutas[k])
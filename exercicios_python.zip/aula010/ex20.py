nomes = ['Maria', 'Pedro', 'João']

while x in nomes:
    print(x)
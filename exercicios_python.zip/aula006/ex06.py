nota = float(input("Digite a nota entre 0 e 100: "))
if nota > 100:
    print("Nota inválida!")
elif nota <= 49:
    print(f"Sua nota foi {nota}. Conceito D.")
elif nota >= 50 and nota <= 60:
    print(f"Sua nota foi {nota}. Conceito C.")
elif nota >= 70 and nota <= 80:
    print(f"Sua nota foi {nota}. Conceito B.")
else:
    print(f"Sua nota foi {nota}. Conceito A.")
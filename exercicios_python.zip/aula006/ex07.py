pontos = int(input("Digite a quantidade de pontos necessária: "))
dolar = float(input("Digite a cotação atual do dolar: "))
pontos_atual = pontos / 1.5
valor = pontos_atual * dolar
print(f"Você precisa gastar R$ {valor:.2f} para conseguir acumular {pontos}.")
numero = int(input("Digite um numero inteiro: "))
if ((numero % 3) == 0) and ((numero % 5) == 0):
    print(f"O número {numero} é divisível por 3 e 5!!!")
else:
    print(f"O número {numero} não é divisível por 3 e 5!!!")
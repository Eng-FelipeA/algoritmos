combustivel = input("Digite o tipo de combustível A, G ou D: ")
l = float(input("Digite o volume abastecido: "))
if combustivel == "A" or combustivel == "a":
    valor = l * 1.7997
    print(f"Você abasteceu {l:.2f}l de etanol. Valor total R$ {valor:.2f}.")
elif combustivel == "G" or combustivel == "g":
    valor = l * 2.109
    print(f"Você abasteceu {l:.2f}l de gasolina. Valor total R$ {valor:.2f}.")
elif combustivel == "D" or combustivel == "d":
    valor = l * 0.9798
    print(f"Você abasteceu {l:.2f}l de diesel. Valor total R$ {valor:.2f}.")
else:
    print("Código não cadastrado!")
n1 = int(input("Digite um número inteiro: "))
n2 = int(input("Digite outro númeo inteiro: "))
total = n1 + n2
if total < 1000:
    print(f"A soma entre {n1} e {n2} é igual a {total}, ou seja, menor que 1000.")
else:
    print(f"A soma entre {n1} e {n2} é igual a {total}, ou seja, maior que 1000.")
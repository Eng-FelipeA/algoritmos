n = input('Digite 9 números aleatórios: ')
milhao = n[0]
milhar = n[1:4]
cent = n[4:7]
decimal = n[7:9]
novo_n = milhao + "." + milhar + "." + cent + "," + decimal
print(novo_n)
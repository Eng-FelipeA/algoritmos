produto = float(input("Digite o valor do produto: "))
cod = int(input("Digite o código de origem: "))
if cod == 1:
    valor = produto + (produto * 0.11)
    print(f"Procedência Sul, imposto é de 11% e valor final é R$ {valor:.2f}.")
elif cod == 2:
    valor = produto + (produto * 0.13)
    print(f"Procedência Norte, imposto é de 13% e o valor final é R$ {valor:.2f}.")
elif cod == 3:
    valor = produto + (produto * 0.09)
    print(f"Procedência Nordeste, imposto é de 9% e o valor final é R$ {valor:.2f}.")
elif cod == 4:
    valor = produto + (produto * 0.12)
    print(f"Procedência Centro-Oeste, imposto é de 12% e o valor final é R$ {valor:.2f}.")
elif cod == 5:
    valor = produto + (produto * 0.18)
    print(f"Procedência Sudeste, imposto é de 18% e o valor final é R$ {valor:.2f}.")
else:
    print("Código de origem inválido!")

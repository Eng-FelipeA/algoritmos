idade = int(input("Digite a idade do competidor: "))

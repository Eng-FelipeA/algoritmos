sexo = input("Digite seu sexo m ou f: ")
h = float(input("Digite sua altura: "))
if sexo == "m":
    peso_ideal = (72.7 * h) - 58
else:
    peso_ideal = (62.1 * h) - 44.7
print(f"Seu peso ideal é {peso_ideal}Kg.")

ano = int(input("Digite o ano de seu nascimento: "))
ano_atual = int(input("Digite o ano atual no formato aaaa: "))

idade = ano_atual - ano

if idade < 16:
    print(f"Sua idade é {idade} anos, ainda não pode votar e nem dirigir.")
elif idade >= 16 and idade < 18:
    print(f"Sua idade é {idade} anos, pode votar mas não pode dirigir.")
else:
    print(f"Sua idade é {idade} anos, pode votar e encher a cara.")
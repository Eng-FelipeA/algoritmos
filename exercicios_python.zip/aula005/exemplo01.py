numero = int(input("Digite um número inteiro positivo: "))
if (numero % 2) == 0:
    print("O número digitado é par!")
else:
    print("O número digitado é impar!")
n1 = int(input("Digite o primeiro número: "))
n2 = int(input("Digite o segundo número: "))
x = int(input("Digite 1 para média, 2 para subtação, 3 para multilplicação ou 4 para divisão: "))
if n2 > n1:
    n1, n2 = n2, n1
else:
    n1, n2
if x == 1:
  n3 = (n1 + n2)/2
  print(f"A média entre os numeros {n1} e {n2} é {n3}.")
elif x == 2:
  n3 = n1 - n2
  print(f"A subtração entre os numeros {n1} e {n2} é {n3}.")
elif x == 3:
  n3 = n1 * n2
  print(f"A multiplicação entre os numeros {n1} e {n2} é {n3}.")
elif x == 4:
  n3 = n1 / n2
  print(f"A divisão entre os numeros {n1} e {n2} é {n3}.")
else:
   print(f"{x} Não é um número válido.")

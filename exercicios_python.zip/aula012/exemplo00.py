def mensagem(msg):
    for i in range(len(msg)):
        print("-", end="")
    print(f"\n{msg}")
    for i in range(len(msg)):
        print("-", end="")

mensagem("Bem-vindo!")

print( "\n\nalguma coisa !!\n")

mensagem("Outra Mensagem.")
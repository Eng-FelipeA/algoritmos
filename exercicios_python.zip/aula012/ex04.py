def calcular_mdc(a, b):
    while b != 0:
        a, b = b, a % b
    return a

numero1 = int(input("Digite o primeiro número: "))
numero2 = int(input("Digite o segundo número: "))

mdc = calcular_mdc(numero1, numero2)

print(f"O MDC entre {numero1} e {numero2} é: {mdc}")

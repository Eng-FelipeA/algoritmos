resultado = 0

def soma(a, b):
    resultado = a + b
    return resultado
#...

x = int(input("Digite valor 1: "))
y = int(input("Digite valor 2: "))
print(f"O valor da soma é igual a {soma(x, y)}")
print(resultado)
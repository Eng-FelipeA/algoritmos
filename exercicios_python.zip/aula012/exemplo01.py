def desenha(n=50, x=10):
    for i in range(x, n):
        print("-", end='')
    print()
#...
desenha()
print("** usando funções **")
desenha(x=10, n=40)

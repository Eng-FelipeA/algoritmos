try:
    len(9.4)
except TypeError as e:
    print(f"Aconteceu o seguinte erro: {e}.")
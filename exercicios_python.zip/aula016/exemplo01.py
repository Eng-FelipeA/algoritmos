try:
    pypro()
except NameError:
    print("Função não foi definida!")
except:
    print("Ocorreu um problema!!")

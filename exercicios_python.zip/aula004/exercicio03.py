ano = int(input("Digite o ano do seu nascimento: "))
ano_atual = int(input("Digite o ano atual: "))
idade = ano_atual - ano
meses = idade * 12
dias = idade * 365
semanas = idade * 53
print(f"Sua idade em anos é {idade} anos.")
print(f"Sua idade em meses é {meses} meses.")
print(f"Sua idade em dias é {dias} dias.")
print(f"Sua idade em semanas é {semanas} semanas.")
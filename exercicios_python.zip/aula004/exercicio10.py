x = int(input("Digite um número positivo maior que zero: "))
quad = x**2
cubo = x**3
raiz = x**0.5
print(f"O quadrado de {x} é {quad}, o cubo de {x} é {cubo} e a raiz quadrada de {x} é {raiz}")

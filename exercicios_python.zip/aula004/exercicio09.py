r = float(input("Digite o raio do circulo: "))
pi = 3.1415
area = pi * (r*r)
print(f"A area do circulo de raio {r} é igual à {area}")
salario = float(input("Entre com o salário: "))
aumento_perc = float(input("Entre com o aumento em %: "))
aumento = salario * (aumento_perc / 100)
novo_salario = salario + aumento
print(f"Você recebeu R$ {aumento:.2f} de aumento e seu novo salário é R$ {novo_salario:.2f}")
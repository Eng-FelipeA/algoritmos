base = float(input("Digite a base do triângulo: "))
altura = float(input("Digite a altura do triângulo: "))
area = (base * altura)/2
print(f"A área do triângulo de base {base:.2f} e altura {altura:.2f} é igual à {area}.")
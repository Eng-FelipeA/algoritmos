d = float(input("Digite a altura do degrau em cm: "))
h = float(input("Digite a altura a ser alcançada em m: "))
qdt_d = h / (d*100)
print(f"Para atingir {h}m de altura, serão necessários {qdt_d} degraus")
data_n = input("Entre com sua data de nascimento dd/mm/aaaa: ")
data_a = input("Entre com a data atual dd/mm/aaaa: ")
dia_n = data_n[0:2]
mes_n = data_n[3:5]
ano_n = data_n[6:10]
dia_a = data_a[0:2]
mes_a = data_a[3:5]
ano_a = data_a[6:10]
idade_anos = int(ano_a) - int(ano_n)
idade_mes = int(mes_a) - int(mes_n)
idade_dias = int(dia_a) - int(dia_n)
print(f"Sua idade é {idade_anos} anos, {idade_mes} meses e {idade_dias} dias.")
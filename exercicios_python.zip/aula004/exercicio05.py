salario = float(input("Entre com o salário: "))
aumento = salario * 0.25
novo_salario = salario + aumento
print(f"O novo salário é R$ {novo_salario:.2f}")
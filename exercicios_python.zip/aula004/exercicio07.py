deposito = float(input("Entre com o depósito: "))
taxa = float(input("Entre com a taxa mensal em %: "))
rendimento = deposito * (taxa / 100)
total = deposito + rendimento
print(f"Sua aplicação rendeu R$ {rendimento:.2f} você possui o total de R$ {total:.2f} aplicados")
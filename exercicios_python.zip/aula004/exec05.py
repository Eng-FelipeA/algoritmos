salario = float(input("Digite o salário: R$ "))
novo_salario = salario * 1.25
print(f"Salário Original...: R$ {salario}")
print(f"Novo Salário c/ 25%: R$ {novo_salario:.2f}")
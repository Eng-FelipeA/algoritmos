nome = input("Escreva seu nome: ")
print(f"Bom dia {nome}.")

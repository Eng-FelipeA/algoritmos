arquivo = open("texto.txt", encoding="utf-8")
texto = arquivo.read()
print(texto)
arquivo.close()

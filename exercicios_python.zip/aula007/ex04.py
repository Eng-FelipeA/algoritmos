soma = 0
contagem = 0
while True:
    numero = int(input('Digite um número par (ou 0 para sair): '))
    if numero % 2 == 0 and numero != 0:
        soma += numero
        contagem += 1
    if numero == 0:
        break
if contagem > 0:
    media = soma / contagem
    print(f'A média aritmética dos números pares é: {media:.2f}')
else:
    print('Nenhum número par foi inserido.')

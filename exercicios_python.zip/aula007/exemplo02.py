for elemento in range(10):
    if elemento == 7:
        break
    print(elemento)
else:
    print("Laço chegou ao fim")


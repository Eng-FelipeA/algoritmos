import time
tempo_total = 10 * 60
while tempo_total >= 0:
    minutos = tempo_total // 60
    segundos = tempo_total % 60
    tempo_formatado = f'{minutos:02d}:{segundos:02d}'
    print(tempo_formatado)
    time.sleep(1)
    tempo_total -= 1

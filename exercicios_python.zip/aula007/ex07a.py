def fibonacci():
    fibo = [0, 1]
    while len(fibo) < 10:
        proximo = fibo[-1] + fibo[-2]
        fibo.append(proximo)
    return fibo
sequencia = fibonacci()
print("Os 10 primeiros números da sequência de Fibonacci são:")
for n in sequencia:
    print(n, end=" ")
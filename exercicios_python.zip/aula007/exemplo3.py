while True:
    n = int(input("Digite um valor inteiro entre 0 e 10: "))
    if (0 <= n <= 10):
        break
print("Legal! Voce digitou um valor válido!!")
n = int(input("Digite um número inteiro maior que 1: "))
if n > 1:
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            print(f"O número {n} não é primo.")
            break
    else:
        print(f"O número {n} é primo.")
else:
    print("O número deve ser maior que 1.")

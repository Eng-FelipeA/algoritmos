soma_peso = 0
soma_altura = 0
maior_imc = float('-inf')
menor_imc = float('inf')
for i in range(1, 6):
    peso = float(input(f'Digite o peso em Kg da {i}ª pessoa: '))
    altura = float(input(f'Digite a altura em m da {i}ª pessoa: '))
    soma_peso += peso
    soma_altura += altura
    imc = peso / (altura ** 2)
    if imc > maior_imc:
        maior_imc = imc
    if imc < menor_imc:
        menor_imc = imc
peso_medio = soma_peso / 5
altura_media = soma_altura / 5
print(f'Peso médio: {peso_medio:.2f} kg')
print(f'Altura média: {altura_media:.2f} metros')
print(f'Maior IMC: {maior_imc:.2f}')
print(f'Menor IMC: {menor_imc:.2f}')
